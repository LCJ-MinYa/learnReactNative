'use strict';

import React, {
	Component
} from 'react';

import {
	StyleSheet,
	View,
	Text
} from 'react-native';

import BaseContainer from '../common/baseContainer'

class Child extends Component {
	render() {
		return (
			<View>
				<Text>{this.props.text}</Text>
			</View>
		)
	}
}

class fatherToChild extends BaseContainer {
	renderDom() {
		return (
			<View>
				<Child text={'子组件的名称'}/>
			</View>
		)
	}
}

const styles = StyleSheet.create({

});


export default fatherToChild;